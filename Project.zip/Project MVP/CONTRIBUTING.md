```bash
# Install dependencies
pnpm install

# Run development servers
pnpm dev:all
```