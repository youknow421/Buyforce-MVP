import React from 'react'

// Theme toggle removed — stub to preserve imports if any
export default function ThemeToggle(){
  return null
}