export const tokens = {
  colors: {
    primary: '#2563eb',
    text: '#0f172a',
    muted: '#6b7280'
  }
};

export const Button = ({ children, onPress }: { children: React.ReactNode; onPress?: () => void }) => {
  // placeholder for React Native Button
  return null as any;
};