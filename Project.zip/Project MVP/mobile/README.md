# Project MVP — Mobile (Expo)

This is an Expo-managed React Native app scaffold for the Project MVP.

Getting started:

1. Install pnpm (recommended): `npm i -g pnpm`
2. From the repo root: `pnpm install`
3. Start the app: `pnpm --filter project-mvp-mobile start` (or `pnpm --filter project-mvp-mobile run start`)

Notes:
- We use TypeScript for the mobile app.
- The app currently includes a minimal product list for initial validation.
