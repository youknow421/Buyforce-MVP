// In-memory user database (replace with real DB in production)
import bcrypt from 'bcryptjs'
import { v4 as uuidv4 } from 'uuid'

export interface User {
  id: string
  email: string
  passwordHash: string
  name: string
  emailVerified: boolean
  verificationToken: string | null
  verificationTokenExpiry: Date | null
  resetToken: string | null
  resetTokenExpiry: Date | null
  createdAt: Date
  updatedAt: Date
}

export type PublicUser = Omit<User, 'passwordHash' | 'verificationToken' | 'verificationTokenExpiry' | 'resetToken' | 'resetTokenExpiry'>

// In-memory store (replace with PostgreSQL/MongoDB in production)
const users = new Map<string, User>()
const emailIndex = new Map<string, string>() // email -> id
const verificationTokenIndex = new Map<string, string>() // token -> userId
const resetTokenIndex = new Map<string, string>() // resetToken -> userId

export function generateUserId(): string {
  return `usr_${Date.now()}_${uuidv4().slice(0, 8)}`
}

export function generateVerificationToken(): string {
  return `vrf_${uuidv4()}`
}

export function generateResetToken(): string {
  return `rst_${uuidv4()}`
}

export interface CreateUserResult {
  user: PublicUser
  verificationToken: string
}

export async function createUser(data: {
  email: string
  password: string
  name: string
}): Promise<CreateUserResult> {
  const normalizedEmail = data.email.toLowerCase().trim()
  
  // Check if email already exists
  if (emailIndex.has(normalizedEmail)) {
    throw new Error('Email already registered')
  }

  const passwordHash = await bcrypt.hash(data.password, 12)
  const verificationToken = generateVerificationToken()
  const verificationTokenExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
  
  const user: User = {
    id: generateUserId(),
    email: normalizedEmail,
    passwordHash,
    name: data.name.trim(),
    emailVerified: false,
    verificationToken,
    verificationTokenExpiry,
    resetToken: null,
    resetTokenExpiry: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  }

  users.set(user.id, user)
  emailIndex.set(normalizedEmail, user.id)
  verificationTokenIndex.set(verificationToken, user.id)

  return { user: toPublicUser(user), verificationToken }
}

export async function verifyPassword(user: User, password: string): Promise<boolean> {
  return bcrypt.compare(password, user.passwordHash)
}

export function getUserById(id: string): User | undefined {
  return users.get(id)
}

export function getUserByEmail(email: string): User | undefined {
  const normalizedEmail = email.toLowerCase().trim()
  const userId = emailIndex.get(normalizedEmail)
  if (!userId) return undefined
  return users.get(userId)
}

export function updateUser(id: string, data: Partial<Pick<User, 'name' | 'email'>>): PublicUser | undefined {
  const user = users.get(id)
  if (!user) return undefined

  if (data.name) {
    user.name = data.name.trim()
  }

  if (data.email && data.email !== user.email) {
    const normalizedEmail = data.email.toLowerCase().trim()
    if (emailIndex.has(normalizedEmail)) {
      throw new Error('Email already in use')
    }
    emailIndex.delete(user.email)
    user.email = normalizedEmail
    emailIndex.set(normalizedEmail, user.id)
  }

  user.updatedAt = new Date()
  users.set(id, user)

  return toPublicUser(user)
}

export async function changePassword(id: string, newPassword: string): Promise<boolean> {
  const user = users.get(id)
  if (!user) return false

  user.passwordHash = await bcrypt.hash(newPassword, 12)
  user.updatedAt = new Date()
  users.set(id, user)

  return true
}

export function toPublicUser(user: User): PublicUser {
  const { passwordHash, verificationToken, verificationTokenExpiry, ...publicUser } = user
  return publicUser
}

export function verifyEmail(token: string): PublicUser | null {
  const userId = verificationTokenIndex.get(token)
  if (!userId) return null
  
  const user = users.get(userId)
  if (!user) return null
  
  // Check if token has expired
  if (user.verificationTokenExpiry && user.verificationTokenExpiry < new Date()) {
    return null
  }
  
  // Mark email as verified
  user.emailVerified = true
  user.verificationToken = null
  user.verificationTokenExpiry = null
  user.updatedAt = new Date()
  users.set(userId, user)
  
  // Clean up token index
  verificationTokenIndex.delete(token)
  
  return toPublicUser(user)
}

export function regenerateVerificationToken(userId: string): string | null {
  const user = users.get(userId)
  if (!user) return null
  
  // Delete old token from index
  if (user.verificationToken) {
    verificationTokenIndex.delete(user.verificationToken)
  }
  
  // Generate new token
  const verificationToken = generateVerificationToken()
  user.verificationToken = verificationToken
  user.verificationTokenExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
  user.updatedAt = new Date()
  users.set(userId, user)
  
  verificationTokenIndex.set(verificationToken, userId)
  
  return verificationToken
}

// Password Reset Functions
export function createPasswordResetToken(email: string): { token: string; user: User } | null {
  const normalizedEmail = email.toLowerCase().trim()
  const userId = emailIndex.get(normalizedEmail)
  if (!userId) return null
  
  const user = users.get(userId)
  if (!user) return null
  
  // Delete old reset token if exists
  if (user.resetToken) {
    resetTokenIndex.delete(user.resetToken)
  }
  
  const resetToken = generateResetToken()
  user.resetToken = resetToken
  user.resetTokenExpiry = new Date(Date.now() + 60 * 60 * 1000) // 1 hour
  user.updatedAt = new Date()
  users.set(userId, user)
  
  resetTokenIndex.set(resetToken, userId)
  
  return { token: resetToken, user }
}

export function verifyResetToken(token: string): User | null {
  const userId = resetTokenIndex.get(token)
  if (!userId) return null
  
  const user = users.get(userId)
  if (!user) return null
  
  // Check if token has expired
  if (!user.resetTokenExpiry || user.resetTokenExpiry < new Date()) {
    // Clean up expired token
    resetTokenIndex.delete(token)
    user.resetToken = null
    user.resetTokenExpiry = null
    users.set(userId, user)
    return null
  }
  
  return user
}

export async function resetPassword(token: string, newPassword: string): Promise<PublicUser | null> {
  const user = verifyResetToken(token)
  if (!user) return null
  
  // Update password
  user.passwordHash = await bcrypt.hash(newPassword, 12)
  user.resetToken = null
  user.resetTokenExpiry = null
  user.updatedAt = new Date()
  users.set(user.id, user)
  
  // Clean up token index
  resetTokenIndex.delete(token)
  
  return toPublicUser(user)
}

export function deleteUser(id: string): boolean {
  const user = users.get(id)
  if (!user) return false

  emailIndex.delete(user.email)
  users.delete(id)
  return true
}
// Admin helper functions
export function getUserCount(): number {
  return users.size
}

export function getAllUsers(): PublicUser[] {
  return Array.from(users.values()).map(toPublicUser)
}

export function getPublicUserById(id: string): PublicUser | null {
  const user = users.get(id)
  return user ? toPublicUser(user) : null
}