// Email service - Mock implementation (replace with SendGrid/Mailgun in production)

export interface EmailOptions {
  to: string
  subject: string
  html: string
  text?: string
}

const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173'

// Mock email sending - logs to console
// Replace with real email service in production:
// - SendGrid: https://sendgrid.com
// - Mailgun: https://mailgun.com
// - AWS SES: https://aws.amazon.com/ses
export async function sendEmail(options: EmailOptions): Promise<boolean> {
  console.log('\n📧 ═══════════════════════════════════════')
  console.log('   EMAIL SENT (Mock)')
  console.log('═══════════════════════════════════════════')
  console.log(`To: ${options.to}`)
  console.log(`Subject: ${options.subject}`)
  console.log('───────────────────────────────────────────')
  console.log(options.text || options.html.replace(/<[^>]*>/g, ''))
  console.log('═══════════════════════════════════════════\n')
  
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 100))
  
  return true
}

export async function sendVerificationEmail(email: string, token: string, name: string): Promise<boolean> {
  const verifyUrl = `${FRONTEND_URL}/verify-email?token=${token}`
  
  return sendEmail({
    to: email,
    subject: 'Verify your email address',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #333;">Welcome, ${name}!</h1>
        <p>Thank you for registering. Please verify your email address by clicking the button below:</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${verifyUrl}" 
             style="background-color: #4F46E5; color: white; padding: 12px 24px; 
                    text-decoration: none; border-radius: 6px; display: inline-block;">
            Verify Email
          </a>
        </div>
        <p style="color: #666; font-size: 14px;">
          Or copy and paste this link into your browser:<br>
          <a href="${verifyUrl}">${verifyUrl}</a>
        </p>
        <p style="color: #666; font-size: 14px;">
          This link will expire in 24 hours.
        </p>
        <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
        <p style="color: #999; font-size: 12px;">
          If you didn't create an account, you can safely ignore this email.
        </p>
      </div>
    `,
    text: `
Welcome, ${name}!

Thank you for registering. Please verify your email address by clicking the link below:

${verifyUrl}

This link will expire in 24 hours.

If you didn't create an account, you can safely ignore this email.
    `.trim()
  })
}

export async function sendPasswordResetEmail(email: string, token: string, name: string): Promise<boolean> {
  const resetUrl = `${FRONTEND_URL}/reset-password?token=${token}`
  
  return sendEmail({
    to: email,
    subject: 'Reset your password',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #333;">Password Reset Request</h1>
        <p>Hi ${name},</p>
        <p>We received a request to reset your password. Click the button below to create a new password:</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetUrl}" 
             style="background-color: #4F46E5; color: white; padding: 12px 24px; 
                    text-decoration: none; border-radius: 6px; display: inline-block;">
            Reset Password
          </a>
        </div>
        <p style="color: #666; font-size: 14px;">
          Or copy and paste this link into your browser:<br>
          <a href="${resetUrl}">${resetUrl}</a>
        </p>
        <p style="color: #666; font-size: 14px;">
          This link will expire in 1 hour.
        </p>
        <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
        <p style="color: #999; font-size: 12px;">
          If you didn't request a password reset, you can safely ignore this email.
        </p>
      </div>
    `,
    text: `
Hi ${name},

We received a request to reset your password. Click the link below to create a new password:

${resetUrl}

This link will expire in 1 hour.

If you didn't request a password reset, you can safely ignore this email.
    `.trim()
  })
}
