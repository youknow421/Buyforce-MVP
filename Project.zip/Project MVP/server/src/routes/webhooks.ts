import { Router, Request, Response } from 'express'
import crypto from 'crypto'
import * as db from '../db.js'

const router = Router()

// Tranzilla webhook endpoint
router.post('/tranzilla', async (req: Request, res: Response) => {
  try {
    console.log('Tranzilla webhook received:', req.body)
    
    const { 
      order_id,
      Response: tranzillaResponse,
      ConfirmationCode,
      index,
    } = req.body

    if (!order_id) {
      console.error('Webhook missing order_id')
      res.status(400).json({ error: 'Missing order_id' })
      return
    }

    const order = db.getOrder(order_id)
    if (!order) {
      console.error(`Order not found: ${order_id}`)
      res.status(404).json({ error: 'Order not found' })
      return
    }

    // Tranzilla response codes:
    // 000 = Success
    // 001-999 = Various errors
    const isSuccess = tranzillaResponse === '000'
    const newStatus = isSuccess ? 'completed' : 'failed'
    
    db.updateOrderStatus(
      order_id, 
      newStatus, 
      isSuccess ? ConfirmationCode || index : undefined
    )

    console.log(`Order ${order_id} updated to ${newStatus}`)

    // TODO: Send confirmation email
    // await sendOrderConfirmationEmail(order, newStatus)

    res.json({ success: true })
  } catch (error) {
    console.error('Tranzilla webhook error:', error)
    res.status(500).json({ error: 'Webhook processing failed' })
  }
})

// Mock payment webhook (for development)
router.post('/mock', async (req: Request, res: Response) => {
  try {
    const { orderId, status } = req.body
    
    if (!orderId || !status) {
      res.status(400).json({ error: 'Missing orderId or status' })
      return
    }

    const validStatuses = ['success', 'failed', 'cancelled']
    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: 'Invalid status' })
      return
    }

    const statusMap: Record<string, db.OrderStatus> = {
      success: 'completed',
      failed: 'failed',
      cancelled: 'cancelled',
    }

    const order = db.updateOrderStatus(orderId, statusMap[status])
    if (!order) {
      res.status(404).json({ error: 'Order not found' })
      return
    }

    console.log(`Mock webhook: Order ${orderId} -> ${statusMap[status]}`)
    res.json({ success: true, order })
  } catch (error) {
    console.error('Mock webhook error:', error)
    res.status(500).json({ error: 'Webhook processing failed' })
  }
})

// Signature verification middleware (for production)
export function verifyWebhookSignature(secret: string) {
  return (req: Request, res: Response, next: Function) => {
    const signature = req.headers['x-webhook-signature'] as string
    
    if (!signature) {
      // Allow unsigned requests in development
      if (process.env.NODE_ENV === 'development') {
        return next()
      }
      res.status(401).json({ error: 'Missing signature' })
      return
    }

    const payload = JSON.stringify(req.body)
    const expectedSig = crypto
      .createHmac('sha256', secret)
      .update(payload)
      .digest('hex')

    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) {
      res.status(401).json({ error: 'Invalid signature' })
      return
    }

    next()
  }
}

export default router
