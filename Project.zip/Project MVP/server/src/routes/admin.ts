import express from 'express'
import { requireAuth, AuthenticatedRequest } from '../auth.js'
import * as users from '../users.js'
import * as db from '../db.js'

const router = express.Router()

// In-memory product storage (for demo - in production use a database)
let products: any[] = [
  { id: '1', name: 'Wireless Headphones', description: 'High-quality wireless headphones with noise cancellation', price: 199.99, category: 'Electronics', stock: 50, image: '' },
  { id: '2', name: 'Smart Watch', description: 'Feature-rich smartwatch with health monitoring', price: 299.99, category: 'Electronics', stock: 30, image: '' },
  { id: '3', name: 'Laptop Stand', description: 'Ergonomic aluminum laptop stand', price: 49.99, category: 'Electronics', stock: 100, image: '' },
  { id: '4', name: 'USB-C Hub', description: '7-in-1 USB-C hub with HDMI and card reader', price: 79.99, category: 'Electronics', stock: 75, image: '' },
  { id: '5', name: 'Mechanical Keyboard', description: 'RGB mechanical gaming keyboard', price: 149.99, category: 'Electronics', stock: 25, image: '' },
]

// Simple admin check middleware (in production, check user.role === 'admin')
const isAdmin = (req: AuthenticatedRequest, res: express.Response, next: express.NextFunction) => {
  // For demo, all authenticated users can access admin
  // In production: if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Forbidden' })
  next()
}

// Dashboard Stats
router.get('/stats', requireAuth, isAdmin, (req: AuthenticatedRequest, res) => {
  const allOrders = db.listOrders()
  const today = new Date()
  today.setHours(0, 0, 0, 0)

  const stats = {
    totalRevenue: allOrders.reduce((sum, o) => sum + o.total, 0),
    ordersToday: allOrders.filter(o => new Date(o.createdAt) >= today).length,
    pendingOrders: allOrders.filter(o => o.status === 'pending').length,
    totalProducts: products.length,
    totalCustomers: users.getUserCount(),
  }

  res.json(stats)
})

// Orders Management
router.get('/orders', requireAuth, isAdmin, (req: AuthenticatedRequest, res) => {
  const { status, page = '1', limit = '50' } = req.query
  let allOrders = db.listOrders()

  if (status && status !== 'all') {
    allOrders = allOrders.filter(o => o.status === status)
  }

  // Sort by date descending
  allOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

  const pageNum = parseInt(page as string)
  const limitNum = parseInt(limit as string)
  const start = (pageNum - 1) * limitNum
  const paginatedOrders = allOrders.slice(start, start + limitNum)

  res.json({
    orders: paginatedOrders,
    total: allOrders.length,
    page: pageNum,
    limit: limitNum,
  })
})

router.get('/orders/:id', requireAuth, isAdmin, (req: AuthenticatedRequest, res) => {
  const order = db.getOrder(req.params.id)
  if (!order) {
    return res.status(404).json({ error: 'Order not found' })
  }
  res.json({ order })
})

router.patch('/orders/:id/status', requireAuth, isAdmin, (req: AuthenticatedRequest, res) => {
  const { status, transactionId } = req.body
  const validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled']
  
  if (!validStatuses.includes(status)) {
    return res.status(400).json({ error: 'Invalid status' })
  }

  const order = db.updateOrderStatus(req.params.id, status, transactionId)
  if (!order) {
    return res.status(404).json({ error: 'Order not found' })
  }

  res.json({ order })
})

// Products Management
router.get('/products', requireAuth, isAdmin, (req: AuthenticatedRequest, res) => {
  res.json({ products, total: products.length })
})

router.get('/products/:id', requireAuth, isAdmin, (req: AuthenticatedRequest, res) => {
  const product = products.find(p => p.id === req.params.id)
  if (!product) {
    return res.status(404).json({ error: 'Product not found' })
  }
  res.json({ product })
})

router.post('/products', requireAuth, isAdmin, (req: AuthenticatedRequest, res) => {
  const { name, description, price, category, stock, image } = req.body

  if (!name || !description || price === undefined || !category) {
    return res.status(400).json({ error: 'Missing required fields' })
  }

  const newProduct = {
    id: Date.now().toString(),
    name,
    description,
    price: parseFloat(price),
    category,
    stock: stock ? parseInt(stock) : 0,
    image: image || '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }

  products.push(newProduct)
  res.status(201).json({ product: newProduct })
})

router.patch('/products/:id', requireAuth, isAdmin, (req: AuthenticatedRequest, res) => {
  const index = products.findIndex(p => p.id === req.params.id)
  if (index === -1) {
    return res.status(404).json({ error: 'Product not found' })
  }

  const { name, description, price, category, stock, image } = req.body
  const product = products[index]

  products[index] = {
    ...product,
    name: name ?? product.name,
    description: description ?? product.description,
    price: price !== undefined ? parseFloat(price) : product.price,
    category: category ?? product.category,
    stock: stock !== undefined ? parseInt(stock) : product.stock,
    image: image ?? product.image,
    updatedAt: new Date().toISOString(),
  }

  res.json({ product: products[index] })
})

router.delete('/products/:id', requireAuth, isAdmin, (req: AuthenticatedRequest, res) => {
  const index = products.findIndex(p => p.id === req.params.id)
  if (index === -1) {
    return res.status(404).json({ error: 'Product not found' })
  }

  const deleted = products.splice(index, 1)[0]
  res.json({ message: 'Product deleted', product: deleted })
})

// Customers Management
router.get('/customers', requireAuth, isAdmin, (req: AuthenticatedRequest, res) => {
  const { page = '1', limit = '50' } = req.query
  const allCustomers = users.getAllUsers()

  // Sort by creation date descending
  allCustomers.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

  const pageNum = parseInt(page as string)
  const limitNum = parseInt(limit as string)
  const start = (pageNum - 1) * limitNum
  const paginatedCustomers = allCustomers.slice(start, start + limitNum)

  res.json({
    customers: paginatedCustomers,
    total: allCustomers.length,
    page: pageNum,
    limit: limitNum,
  })
})

router.get('/customers/:id', requireAuth, isAdmin, (req: AuthenticatedRequest, res) => {
  const customer = users.getPublicUserById(req.params.id)
  if (!customer) {
    return res.status(404).json({ error: 'Customer not found' })
  }

  // Get customer orders
  const customerOrders = db.listOrders(customer.email)

  res.json({
    customer,
    orders: customerOrders,
  })
})

export default router
